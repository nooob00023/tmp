import './seting.js';
import {
	createRequire
} from "module";
import path, {
	join
} from 'path'
import {
	fileURLToPath,
	pathToFileURL
} from 'url'
import {
	platform
} from 'process'
import * as ws from 'ws';
import {
	readdirSync,
	statSync,
	unlinkSync,
	existsSync,
	readFileSync,
	watch,
	rmSync
} from 'fs';
import yargs from 'yargs';
import {
	spawn
} from 'child_process';
import lodash from 'lodash';
import chalk from 'chalk'
import syntaxerror from 'syntax-error';
import {
	tmpdir
} from 'os';
import {
	format
} from 'util';
import {
	makeWASocket,
	protoType,
	serialize
} from './lib/simple.js';
import {
	Low,
	JSONFile
} from 'lowdb';
import pino from 'pino';
import {
	mongoDB,
	mongoDBV2
} from './lib/mongoDB.js';
import store from './lib/store.js'
import {
	Boom
} from '@hapi/boom'
const {
	useMultiFileAuthState,
	DisconnectReason,
	fetchLatestBaileysVersion,
	MessageRetryMap,
	makeCacheableSignalKeyStore,
	jidNormalizedUser,
	PHONENUMBER_MCC
} = await import('@whiskeysockets/baileys')
import moment from 'moment-timezone'
import NodeCache from 'node-cache'
import readline from 'readline'
import fs from 'fs'
const {
	CONNECTING
} = ws
const {
	chain
} = lodash

protoType()
serialize()

global.__filename = function filename(pathURL = import.meta.url, rmPrefix = platform !== 'win32') {
	return rmPrefix ? /file:\/\/\//.test(pathURL) ? fileURLToPath(pathURL) : pathURL : pathToFileURL(pathURL).toString()
};
global.__dirname = function dirname(pathURL) {
	return path.dirname(global.__filename(pathURL, true))
};
global.__require = function require(dir = import.meta.url) {
	return createRequire(dir)
}

global.API = (name, path = '/', query = {}, apikeyqueryname) => (name in global.APIs ? global.APIs[name] : name) + path + (query || apikeyqueryname ? '?' + new URLSearchParams(Object.entries({
	...query,
	...(apikeyqueryname ? {
		[apikeyqueryname]: global.APIKeys[name in global.APIs ? global.APIs[name] : name]
	} : {})
})) : '')
global.timestamp = {
	start: new Date
}

const __dirname = global.__dirname(import.meta.url)

global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse())
global.prefix = new RegExp('^[' + (opts['prefix'] || '‎z/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.,\\-').replace(/[|\\{}()[\]^$+*?.\-\^]/g, '\\$&') + ']')

global.db = new Low(
	/https?:\/\//.test(opts['db'] || '') ?
	new cloudDBAdapter(opts['db']) : /mongodb(\+srv)?:\/\//i.test(opts['db']) ?
	(opts['mongodbv2'] ? new mongoDBV2(opts['db']) : new mongoDB(opts['db'])) :
	new JSONFile(`${opts._[0] ? opts._[0] + '_' : ''}database.json`)
)


global.DATABASE = global.db
global.loadDatabase = async function loadDatabase() {
	if (global.db.READ) return new Promise((resolve) => setInterval(async function() {
		if (!global.db.READ) {
			clearInterval(this)
			resolve(global.db.data == null ? global.loadDatabase() : global.db.data)
		}
	}, 1 * 1000))
	if (global.db.data !== null) return
	global.db.READ = true
	await global.db.read().catch(console.error)
	global.db.READ = null
	global.db.data = {
		users: {},
		chats: {},
		stats: {},
		msgs: {},
		sticker: {},
		settings: {},
		...(global.db.data || {})
	}
	global.db.chain = chain(global.db.data)
}
loadDatabase()

global.authFile = `sessions`
const {
	state,
	saveState,
	saveCreds
} = await useMultiFileAuthState(global.authFile)
const msgRetryCounterMap = (MessageRetryMap) => {}
const msgRetryCounterCache = new NodeCache()
const {
	version
} = await fetchLatestBaileysVersion()
let phoneNumber = global.botNumber

const methodCodeQR = process.argv.includes("qr")
const methodCode = !!phoneNumber || process.argv.includes("code")
const MethodMobile = process.argv.includes("mobile")

const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout
})

const question = (text) => new Promise((resolve) => rl.question(text, resolve))

async function selectMethod() {
	let method = null

	if (!fs.existsSync(`./${authFile}/creds.json`) && !methodCodeQR && !methodCode) {
		while (!method) {
			const answer = await question("\n[ PILIH METODE LOGIN ]\n\n1. Scan QR\n2. Pairing Code\n\nPilih: ")
			if (answer === '1' || answer === '2') {
				method = answer
			} else {
				console.log("\n❌ Pilih 1 atau 2 saja!")
			}
		}
	}
	return method
}

const connectionOptions = {
	logger: pino({
		level: 'silent'
	}),
	printQRInTerminal: false,
	mobile: MethodMobile,
	browser: ["Ubuntu", "Chrome", "20.0.04"],
	auth: {
		creds: state.creds,
		keys: makeCacheableSignalKeyStore(state.keys, pino({
			level: "fatal"
		}).child({
			level: "fatal"
		})),
	},
	markOnlineOnConnect: true,
	generateHighQualityLinkPreview: true,
	getMessage: async (key) => {
		let jid = jidNormalizedUser(key.remoteJid)
		let msg = await store.loadMessage(jid, key.id)
		return msg?.message || ""
	},
	msgRetryCounterCache,
	msgRetryCounterMap,
	defaultQueryTimeoutMs: undefined,
	version
}

global.conn = makeWASocket(connectionOptions)

const method = await selectMethod()

if (method === '1' || methodCodeQR) {
	conn.printQRInTerminal = true
}

if (method === '2' || methodCode) {
	if (!conn.authState.creds.registered) {
		if (MethodMobile) throw new Error('❌ Mobile API Error')

		let inputNumber = phoneNumber
		while (!inputNumber) {
			inputNumber = await question("\nMasukkan Nomor WhatsApp (62xxx):\n")
			inputNumber = inputNumber.replace(/[^0-9]/g, '')

			if (!inputNumber.match(/^\d+$/) || !Object.keys(PHONENUMBER_MCC).some(v => inputNumber.startsWith(v))) {
				console.log("\n❌ Nomor tidak valid! Gunakan format: 62xxx")
				inputNumber = null
			}
		}

		console.log("\nGenerating pairing code...")
		setTimeout(async () => {
			try {
				const code = await conn.requestPairingCode(inputNumber)
				console.log(`\n✅ Kode Pairing: ${code?.match(/.{1,4}/g)?.join("-") || code}\n`)
			} catch (e) {
				console.log("\n❌ Gagal generate kode:", e.message)
			}
			rl.close()
		}, 3000)
	}
}

conn.isInit = false

if (!opts['test']) {
	setInterval(async () => {
		if (global.db.data) await global.db.write().catch(console.error)
		if (opts['autocleartmp']) try {
			clearTmp()

		} catch (e) {
			console.error(e)
		}
	}, 60 * 1000)
}

async function clearTmp() {
	const tmp = [tmpdir(), join(__dirname, './tmp')]
	const filename = []
	tmp.forEach(dirname => readdirSync(dirname).forEach(file => filename.push(join(dirname, file))))

	return filename.map(file => {
		const stats = statSync(file)
		if (stats.isFile() && (Date.now() - stats.mtimeMs >= 1000 * 60 * 1)) return unlinkSync(file)
		return false
	})
}

setInterval(async () => {
	await clearTmp()
	//console.log(chalk.cyan(`✅  Hapus otomatis | Folder tmp telah dibersihkan`))
}, 60000)

function clearSessions(folder = 'sessions') {
	let filename = []
	readdirSync(folder).forEach(file => filename.push(join(folder, file)))
	return filename.map(file => {
		let stats = statSync(file)
		if (stats.isFile() &&
			(Date.now() - stats.mtimeMs >= 1000 * 60 * 120) &&
			!file.includes('creds.json')) {
			console.log('Deleted old session:', file)
			return unlinkSync(file)
		}
		return false
	})
}

async function connectionUpdate(update) {
	const {
		receivedPendingNotifications,
		connection,
		lastDisconnect,
		isOnline,
		isNewLogin
	} = update

	if (isNewLogin) {
		conn.isInit = true
		console.log(chalk.green('Login Baru Terdeteksi'))
	}

	switch (connection) {
		case 'connecting':
			console.log(chalk.redBright('Mengaktifkan Bot, Mohon tunggu sebentar...'))
			break
		case 'open':
			console.log(chalk.green('Berhasil Tersambung'))
			break
		case 'close':
			console.log(chalk.red('⏱️ Koneksi Terputus'))

			if (lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut) {
				console.log(chalk.yellow('Mencoba menghubungkan kembali...'))
				await global.reloadHandler(true)
			} else {
				console.log(chalk.red('Koneksi gagal - Logged Out'))
			}
			break
	}

	if (isOnline === true) console.log(chalk.green('Status Aktif'))
	if (isOnline === false) console.log(chalk.red('Status Mati'))

	if (receivedPendingNotifications) {
		console.log(chalk.yellow('Menunggu Pesan Baru'))
	}

	global.timestamp.connect = new Date

	if (global.db.data == null) await global.loadDatabase()
}

async function initConnection() {
	if (!existsSync(global.authFile)) {
		mkdirSync(global.authFile, {
			recursive: true
		})
	}

	try {
		await conn.connect()
	} catch (error) {
		console.error('Kesalahan saat koneksi:', error)
		setTimeout(initConnection, 5000)
	}
}

process.on('uncaughtException', console.error)

let isInit = true;
let handler = await import('./handler.js')
global.reloadHandler = async function(restatConn) {
	try {
		const Handler = await import(`./handler.js?update=${Date.now()}`).catch(console.error)
		if (Object.keys(Handler || {}).length) handler = Handler
	} catch (e) {
		console.error(e)
	}
	if (restatConn) {
		const oldChats = global.conn.chats
		try {
			global.conn.ws.close()
		} catch {}
		conn.ev.removeAllListeners()
		global.conn = makeWASocket(connectionOptions, {
			chats: oldChats
		})
		isInit = true
	}
	if (!isInit) {
		conn.ev.off('messages.upsert', conn.handler)
		conn.ev.off('group-participants.update', conn.participantsUpdate)
		conn.ev.off('groups.update', conn.groupsUpdate)
		conn.ev.off('connection.update', conn.connectionUpdate)
		conn.ev.off('creds.update', conn.credsUpdate)
	}

	conn.welcome = 'Selamat Datang Di @subject\nSilahkan Perkenalkan Diri Kamu @user'
	conn.bye = 'Selamat Tinggal @user\nKalau Balik Jangan Lupa Gorengannya'
	conn.handler = handler.handler.bind(global.conn)
	conn.participantsUpdate = handler.participantsUpdate.bind(global.conn)
	conn.groupsUpdate = handler.groupsUpdate.bind(global.conn)
	conn.connectionUpdate = connectionUpdate.bind(global.conn)
	conn.credsUpdate = saveCreds.bind(global.conn, true)

	conn.ev.on('messages.upsert', conn.handler)
	conn.ev.on('group-participants.update', conn.participantsUpdate)
	conn.ev.on('groups.update', conn.groupsUpdate)
	conn.ev.on('connection.update', conn.connectionUpdate)
	conn.ev.on('creds.update', conn.credsUpdate)
	isInit = false
	return true
}

const pluginFolder = global.__dirname(join(__dirname, './plugins/index'))
const pluginFilter = filename => /\.js$/.test(filename)
global.plugins = {}
async function filesInit() {
	for (let filename of readdirSync(pluginFolder).filter(pluginFilter)) {
		try {
			let file = global.__filename(join(pluginFolder, filename))
			const module = await import(file)
			global.plugins[filename] = module.default || module
		} catch (e) {
			conn.logger.error(e)
			delete global.plugins[filename]
		}
	}
}
filesInit().then(_ => console.log(Object.keys(global.plugins))).catch(console.error)

global.nomor = ['6281324846720@s.whatsapp.net'];
global.reload = async (_ev, filename) => {
    const tanggal = moment().tz('Asia/Jakarta').format('DD MMMM YYYY, HH:mm:ss');
    let dir = global.__filename(join(pluginFolder, filename), true);
    let statusMessage = '';
    let errorMessage = '';

    if (pluginFilter(filename)) {
        if (filename in global.plugins) {
            if (existsSync(dir)) {
                statusMessage = `✅ Plugin di-update`;
            } else {
                statusMessage = `🗑️ Plugin dihapus`;
                delete global.plugins[filename];
            }
        } else {
            statusMessage = `📂 Plugin baru ditambahkan`;
        }

        let err = syntaxerror(readFileSync(dir), filename, {
            sourceType: 'module',
            allowAwaitOutsideFunction: true,
        });

        if (err) {
            errorMessage = `❌ Syntax Error: ${format(err)}`;
        } else {
            try {
                const module = (await import(`${global.__filename(dir)}?update=${Date.now()}`));
                global.plugins[filename] = module.default || module;
            } catch (e) {
                errorMessage = `❌ Error: ${format(e)}`;
            } finally {
                global.plugins = Object.fromEntries(Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b)));
            }
        }

        const logMessage = `
📢 *Lapor Feature: ${statusMessage}*
🧾 *Nama File:* ${filename}
🗓️ *Tanggal:* ${tanggal}
${errorMessage ? `💻 *Pesan Error:* ${errorMessage}` : ''}
        `.trim();

        conn.logger.info(logMessage);
        await notifyTarget(logMessage);
    }
};

async function notifyTarget(message) {
    for (let nomor of global.nomor) {
        await conn.sendMessage(nomor, { text: message });
    }
}
Object.freeze(global.reload)
watch(pluginFolder, global.reload)
await global.reloadHandler()

async function _quickTest() {
	let test = await Promise.all([
		spawn('ffmpeg'),
		spawn('ffprobe'),
		spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-filter_complex', 'color', '-frames:v', '1', '-f', 'webp', '-']),
		spawn('convert'),
		spawn('magick'),
		spawn('gm'),
		spawn('find', ['--version'])
	].map(p => {
		return Promise.race([
			new Promise(resolve => {
				p.on('close', code => {
					resolve(code !== 127)
				})
			}),
			new Promise(resolve => {
				p.on('error', _ => resolve(false))
			})
		])
	}))
	let [ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find] = test
	console.log(test)
	let s = global.support = {
		ffmpeg,
		ffprobe,
		ffmpegWebp,
		convert,
		magick,
		gm,
		find
	}
	Object.freeze(global.support)

	if (!s.ffmpeg) conn.logger.warn('Please install ffmpeg for sending videos (pkg install ffmpeg)')
	if (s.ffmpeg && !s.ffmpegWebp) conn.logger.warn('Stickers may not animated without libwebp on ffmpeg (--enable-ibwebp while compiling ffmpeg)')
	if (!s.convert && !s.magick && !s.gm) conn.logger.warn('Stickers may not work without imagemagick if libwebp on ffmpeg doesnt isntalled (pkg install imagemagick)')
}

_quickTest()
	.then(() => {})
	.catch(console.error);