import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import fs from 'fs'

global.owner = [
  ['6281324846720', 'Ren Collins', true]
]

global.mods = [''] 
global.prems = ['6281324846720']
global.lisensibot = ['']

global.packname = '' 
global.author = 'create by mikasa bot\n\n---- INFORMATION ----\nOwner : ren collins\nWebsite : rendigital.store' 

global.botName = 'Mikasa MD'
global.ownName = 'Ren Collins'
global.desk = '`Mikasa MD` *best bot rpg*\n*Made In* `Ren Collins`'
global.nomorwa = '6281324846720'

global.idch = '120363353537585240@newsletter'
global.saluran = 'https://whatsapp.com/channel/0029VauDwc13QxRtRlQuCD29'
global.gcbot = 'https://chat.whatsapp.com/L7RIYPdEzEBJSJiV29qBvY'

global.multiplier = 69
global.maxwarn = '2'

global.APIs = {
    anu : 'rendigital.store'
}

global.APIKeys = {
    "rendigital.store": "rendigital",
}

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})