import { fileTypeFromBuffer } from "file-type";
import crypto from "crypto";
import fetch from "node-fetch";
import { FormData, Blob } from "formdata-node";

let handler = async (m, { conn, usedPrefix, command, text }) => {
  const fstatus = {
    "key": {
      "fromMe": false,
      "participant": "0@s.whatsapp.net",
      "remoteJid": "status@broadcast"
    },
    "message": {
      "extendedTextMessage": {
        "text": "salomon.my.id",
        "contextInfo": {
          "participant": "0@s.whatsapp.net"
        }
      }
    }
  };

  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || q.mediaType || "";

  const broadcastToGroups = async (groupIds, text, media, mimeType) => {
    conn.reply(m.chat, `_Mengirim pesan broadcast ke ${groupIds.length} grup_`, m);
    for (let id of groupIds) {
      await sleep(2000);
      let participants = (await conn.groupMetadata(id)).participants.map(a => a.id);
      let message = {
        ...(mimeType.startsWith('video') ? { video: { url: media } } :
          mimeType.startsWith('image') ? { image: { url: media } } :
          mimeType.startsWith('audio') ? { audio: { url: media } } : {}), // Use 'audio' for mp3
        caption: text ? text.trim() : '', // Jika tidak ada teks, kirim gambar/stiker tanpa caption
        mentions: participants,
      };
      await conn.sendMessage(id, message, { quoted: fstatus });
    }
    conn.reply(m.chat, 'Broadcast selesai', m);
  };

  if (command === 'bcgcfile' || command === 'bcimg') {
    if (!mime) {
      return conn.reply(m.chat, `Hi kak 👋 ${m.pushName}, Pengguna Command Salah silahkan ikuti contoh di bawah ini:\n\nContoh:\n${usedPrefix}${command} (reply image/video/gif/upload image/video/gif dengan text)`, m);
    }

    let mediaUrl = await uploadToCatbox(await q.download()); // Upload image, video, gif, or mp3
    let getGroups = await conn.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map(entry => entry[1]);
    let groupIds = groups.map(v => v.id);

    await broadcastToGroups(groupIds, text, mediaUrl, mime); // Pass mime type to function
  } else if (command === 'bcgcfiletarget') {
    if (!mime) {
      return conn.reply(m.chat, `Hi kak 👋 ${m.pushName}, Pengguna Command Salah silahkan ikuti contoh di bawah ini:\n\nContoh:\n${usedPrefix}${command} (reply image/video/gif/upload image/video/gif dengan text)`, m);
    }

    let targetId, broadcastText;
    if (!text.includes('|')) {
      targetId = text.trim(); // Hanya ID target tanpa teks
      broadcastText = ''; // Teks kosong jika tidak ada '|'
    } else {
      [targetId, broadcastText] = text.split('|').map(t => t.trim());
    }

    let mediaUrl = await uploadToCatbox(await q.download());

    let getGroups = await conn.groupFetchAllParticipating();
    let groupArray = Object.keys(getGroups).map((jid, i) => ({
      id: jid,
      index: (i + 1).toString()
    }));

    let targetGroup = groupArray.find(g => g.index === targetId);
    if (targetGroup) {
      await broadcastToGroups([targetGroup.id], broadcastText, mediaUrl, mime); // Pass mime type
    } else {
      conn.reply(m.chat, 'Grup tidak ditemukan', m);
    }
  } else if (command === 'bcgcfileall') {
    if (!mime) {
      return conn.reply(m.chat, `Hi kak 👋 ${m.pushName}, Pengguna Command Salah silahkan ikuti contoh di bawah ini:\n\nContoh:\n${usedPrefix}${command} <teks>`, m);
    }

    let mediaUrl = await uploadToCatbox(await q.download());
    let getGroups = await conn.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map(entry => entry[1]);
    let groupIds = groups.map(v => v.id);

    await broadcastToGroups(groupIds, text, mediaUrl, mime); // Pass mime type
  }
};

handler.help = ['bcgcfile', 'bcgcfiletarget', 'bcgcfileall'];
handler.tags = ['owner'];
handler.command = /^(bcgcfile|bcimg|bcgcfiletarget|bcgcfileall)$/i;
handler.owner = false;

export default handler;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function uploadToCatbox(content) {
  const { ext, mime } = (await fileTypeFromBuffer(content)) || {};
  const blob = new Blob([content], { type: mime });
  const formData = new FormData();
  const randomBytes = crypto.randomBytes(5).toString("hex");
  formData.append("reqtype", "fileupload");
  formData.append("fileToUpload", blob, randomBytes + "." + ext);

  const response = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: formData,
  });

  return await response.text();
}