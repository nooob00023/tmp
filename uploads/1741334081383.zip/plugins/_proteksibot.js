export async function before(m) {
    let user = db.data.users[m.sender];
    let chat = db.data.chats[m.chat];
    
    const isOwner = [...global.owner].map(([number]) => number).includes(m.sender)
    
    if (isOwner) return;

    if ((m.chat.endsWith('broadcast') || m.fromMe) && !m.message && !chat.isBanned) return;

    if (!m.text.startsWith('.') && 
        !m.text.startsWith('#') && 
        !m.text.startsWith('!') && 
        !m.text.startsWith('/') && 
        !m.text.startsWith('\/') && 
        !m.text.startsWith('z') && 
        !m.text.startsWith('i') && 
        !m.text.startsWith('$') && 
        !m.text.startsWith('%') && 
        !m.text.startsWith('+') && 
        !m.text.startsWith('£') && 
        !m.text.startsWith('¢') && 
        !m.text.startsWith('€') && 
        !m.text.startsWith('¥') && 
        !m.text.startsWith('^') && 
        !m.text.startsWith('°') && 
        !m.text.startsWith('=') && 
        !m.text.startsWith('¶') && 
        !m.text.startsWith('∆') && 
        !m.text.startsWith('×') && 
        !m.text.startsWith('÷') && 
        !m.text.startsWith('π') && 
        !m.text.startsWith('√') && 
        !m.text.startsWith('✓') && 
        !m.text.startsWith('©') && 
        !m.text.startsWith('®') && 
        !m.text.startsWith(':') && 
        !m.text.startsWith(';') && 
        !m.text.startsWith('?') && 
        !m.text.startsWith('&') && 
        !m.text.startsWith('.') && 
        !m.text.startsWith(',') && 
        !m.text.startsWith('\\') && 
        !m.text.startsWith('-')) return;

    if (user.banned) return;

    if (m.fromMe) return;

    if (!this.spam) this.spam = {};

    if (m.sender in this.spam) {
        this.spam[m.sender].count++;

        if (m.messageTimestamp.toNumber() - this.spam[m.sender].lastspam < 15) {
            if (this.spam[m.sender].count >= 3) {
                m.reply('*Peringatan: Jangan spam! Tunggu 15 detik untuk lanjut lagi.*');

                if (this.spam[m.sender].totalSpamCount === 10) {
                    user.banned = true;
                    m.reply('*Kamu di-banned sementara selama 15 detik karena terdeteksi spam.*');
                    setTimeout(() => {
                        user.banned = false;
                    }, 15000); 
                }

                this.spam[m.sender].count = 3;
            }

            this.spam[m.sender].totalSpamCount = this.spam[m.sender].totalSpamCount ? this.spam[m.sender].totalSpamCount + 1 : 1;

            if (this.spam[m.sender].totalSpamCount === 20) {
                user.banned = true;
                m.reply('*Kamu di-banned permanen karena terdeteksi spam terus-menerus.*');
            }
        } else {
            this.spam[m.sender].count = 1;
            this.spam[m.sender].lastspam = m.messageTimestamp.toNumber();
        }
    } else {
        this.spam[m.sender] = {
            jid: m.sender,
            count: 1,
            lastspam: m.messageTimestamp.toNumber(),
            totalSpamCount: 1
        };
    }
}