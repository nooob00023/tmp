import fetch from 'node-fetch';

let handler = async (m, { conn, text, participants }) => {
    const fstatus = {
        "key": {
            "fromMe": false,
            "participant": "0@s.whatsapp.net",
            "remoteJid": "status@broadcast"
        },
        "message": {
            "extendedTextMessage": {
                "text": "salomon.my.id",
                "contextInfo": {
                    "participant": "0@s.whatsapp.net"
                }
            }
        }
    };

    conn.sendMessage(m.chat, { text: text, mentions: participants.map(a => a.id) }, { quoted: fstatus });
}

handler.help = ['hidetag'];
handler.tags = ['group'];
handler.command = ['hidetag', 'h'];
handler.owner = true;

export default handler;