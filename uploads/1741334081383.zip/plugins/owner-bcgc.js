let handler = async (m, { conn, usedPrefix, command, text }) => {
  const fstatus = {
    "key": {
      "fromMe": false,
      "participant": "0@s.whatsapp.net",
      "remoteJid": "status@broadcast"
    },
    "message": {
      "extendedTextMessage": {
        "text": "salomon.my.id",
        "contextInfo": {
          "participant": "0@s.whatsapp.net"
        }
      }
    }
  };

  const broadcastToGroups = async (groupIds, text) => {
    conn.reply(m.chat, `_Mengirim pesan broadcast teks ke ${groupIds.length} grup_`, m);
    for (let id of groupIds) {
      await sleep(2000);
      let participants = (await conn.groupMetadata(id)).participants.map(a => a.id);
      await conn.sendMessage(id, { text: text, mentions: participants }, { quoted: fstatus });
    }
    conn.reply(m.chat, 'Broadcast teks selesai', m);
  };

  if (command === 'broadcastgroup' || command === 'bcgc') {
    if (!text) {
      return conn.reply(m.chat, `Contoh:\n${usedPrefix}${command} (teks)`, m);
    }
  }

  if (command === 'broadcastgroup' || command === 'bcgcall') {
    let getGroups = await conn.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map((entry, index) => {
      let [jid, group] = entry;
      return { id: index + 1, jid, subject: group.subject, read_only: group?.metadata?.read_only };
    });

    let groupIds = groups.map(group => group.jid);

    await broadcastToGroups(groupIds, text);
  } else if (command === 'bcgctarget') {
    if (!text.includes('|')) throw 'Format salah. Gunakan: /bcgctarget id|(text broadcast)';
    let [targetId, broadcastText] = text.split('|');
    targetId = parseInt(targetId.trim());

    let getGroups = await conn.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map((entry, index) => {
      let [jid, group] = entry;
      return { id: index + 1, jid, subject: group.subject, read_only: group?.metadata?.read_only };
    });

    let targetGroup = groups.find(group => group.id === targetId);

    if (targetGroup) {
      await broadcastToGroups([targetGroup.jid], broadcastText.trim());
    } else {
      conn.reply(m.chat, 'Grup tidak ditemukan', m);
    }
  } else if (command === 'listgc') {
    let txt = '';
    let getGroups = await conn.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map((entry, index) => {
      let [jid, group] = entry;
      return { id: index + 1, jid, subject: group.subject, read_only: group?.metadata?.read_only };
    });

    for (let group of groups) {
      txt += `Nama Grup: ${group.subject}\nID: ${group.id}\nStatus: ${group.read_only ? 'Left' : 'Joined'}\n\n`;
    }

    await m.reply(`*List Groups :*\n\n${txt.trim()}`);
  }
};

handler.help = ['broadcastgroup', 'bcgcall', 'bcgctarget', 'listgc'];
handler.tags = ['owner'];
handler.command = /^(broadcastgroup|bcgc|bcgcall|bcgctarget|listgc)$/i;
handler.rowner = true;

export default handler;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}