let handler = async (m, { conn, usedPrefix, command, text }) => {
  const fstatus = {
    "key": {
      "fromMe": false,
      "participant": "0@s.whatsapp.net",
      "remoteJid": "status@broadcast"
    },
    "message": {
      "extendedTextMessage": {
        "text": "rendigital.store",
        "contextInfo": {
          "participant": "0@s.whatsapp.net"
        }
      }
    }
  };

  const broadcastToTargets = async (targets, text) => {
    conn.reply(m.chat, `_Mengirim pesan broadcast teks ke ${targets.length} kontak_`, m);
    for (let id of targets) {
      await sleep(2000);
      await conn.sendMessage(id + '@c.us', { text: text }, { quoted: fstatus });
    }
    conn.reply(m.chat, 'Broadcast teks selesai', m);
  };

  if (command === 'bctarget') {
    if (!text.includes('|')) throw 'Format salah. Gunakan: /bctarget (nomor)|(text broadcast)'; // Perbaiki format
    let [targetNumber, broadcastText] = text.split('|');
    await broadcastToTargets([targetNumber], broadcastText.trim()); // Kirim ke satu nomor
  } 
};

handler.help = ['bctarget (nomor)|(text broadcast)']; // Perbaiki help
handler.tags = ['owner'];
handler.command = /^(bctarget)$/i;
handler.rowner = true;

export default handler;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}