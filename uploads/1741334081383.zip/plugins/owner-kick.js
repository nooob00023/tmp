let handler = async (m, { conn, text, participants, usedPrefix, command }) => {
    let kickte = `Tidak ada yang ditargetkan.\n\nContoh penggunaan:\n*${usedPrefix + command}* @tag\n*${usedPrefix + command}* nomor (contoh: 6281234567890)`

    let user;
    
    if (m.mentionedJid[0]) {
        user = m.mentionedJid[0];
    } else if (m.quoted) {
        user = m.quoted.sender;
    } else if (text) {
        let target = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        let isValid = participants.some(p => p.id === target);
        if (!isValid) return m.reply('❌ Nomor tidak ditemukan dalam grup.');
        user = target;
    } else {
        return m.reply(kickte);
    }

    await conn.groupParticipantsUpdate(m.chat, [user], 'remove');
    m.reply(`✅ Berhasil Kick @${user.split`@`[0]}`, m.chat, { mentions: [user] });
}

handler.help = ['kick']
handler.tags = ['group']
handler.command = ['kick', 'dor', '🔫']
handler.group = true
handler.botAdmin = true
handler.owner = true

export default handler