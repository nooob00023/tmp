import fs from 'fs'
import path from 'path'

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) throw `Mau Disimpan Dengan Nama Apa?`
    if (!m.quoted.text) throw `Balas Pesan Nya!`

    let filePath = path.resolve(`plugins/${text}`)
    let dir = path.dirname(filePath)

    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true })
    }

    fs.writeFileSync(filePath, m.quoted.text)
    m.reply(`Tersimpan di ${filePath}`)
}

handler.help = ['sf']
handler.tags = ['owner']
handler.command = /^sf$/i
handler.owner = true

export default handler