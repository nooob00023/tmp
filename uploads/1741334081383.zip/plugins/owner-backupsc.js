import fs from "fs";
import cp, { exec as _exec } from "child_process";
import { promisify } from "util";
import path from "path";

let exec = promisify(_exec).bind(cp);

let handler = async (m, { conn, isROwner }) => {
   try {
      let namaFileZip = `BackupScript.zip`;

      const daftarPengecualian = [
         "node_modules/*", 
         ".cache/*", 
         ".npm/*"
      ];

      const argumenPengecualian = daftarPengecualian.map(item => `-x "${item}"`).join(' ');

      m.reply("Memulai proses backup. Harap tunggu...");

      const perintahZip = `zip -r ${namaFileZip} . ${argumenPengecualian}`;
      await exec(perintahZip);

      if (!fs.existsSync(namaFileZip)) {
         throw new Error("Gagal membuat file backup");
      }

      const statFile = fs.statSync(namaFileZip);
      if (statFile.size === 0) {
         throw new Error("File backup kosong");
      }

      const file = fs.readFileSync(namaFileZip);
      await conn.sendMessage(
         m.chat,
         {
            document: file,
            mimetype: "application/zip",
            fileName: namaFileZip,
            caption: "Backup selesai (termasuk folder sessions). Silakan unduh file backup.",
         },
         { quoted: m }
      );

      setTimeout(() => {
         try {
            fs.unlinkSync(namaFileZip);
            m.reply("File backup telah dihapus dari server.");
         } catch (errorHapus) {
            m.reply("Gagal menghapus file backup.");
            console.error(errorHapus);
         }
      }, 5000);

   } catch (error) {
      console.error("Kesalahan backup:", error);
      m.reply(`Terjadi kesalahan saat melakukan backup: ${error.message}`);
   }
};

handler.help = ["backupsc"];
handler.tags = ["owner"];
handler.command = ["backupsc"];
handler.rowner = true;

export default handler;