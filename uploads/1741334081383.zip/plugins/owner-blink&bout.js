import { areJidsSameUser } from '@whiskeysockets/baileys'

let handler = async (m, { conn, args, command }) => {
    if (command === 'blink' || command === 'bout') {
        if (!args[0] || isNaN(args[0])) {
            return conn.reply(m.chat, `Contoh penggunaan:\n${command} <nomor urut grup>`, m)
        }
        let groupIndex = parseInt(args[0]) - 1 
        
        let getGroups = await conn.groupFetchAllParticipating()
        let groups = Object.entries(getGroups).map(([jid, group], index) => ({
            id: index + 1,
            jid,
            subject: group.subject,
            read_only: group?.metadata?.read_only
        }))
        
        if (groupIndex < 0 || groupIndex >= groups.length) {
            return conn.reply(m.chat, '⚠️ Nomor urut grup tidak valid.', m)
        }
        let group = groups[groupIndex].jid 

        if (command === 'blink') {
            try {
                let groupMetadata = await conn.groupMetadata(group)
                if (!groupMetadata) throw 'groupMetadata is undefined :\\'
                if (!('participants' in groupMetadata)) throw 'Peserta tidak didefinisikan :('
                let me = groupMetadata.participants.find(user => areJidsSameUser(user.id, conn.user.id))
                if (!me) throw 'Saya tidak berada di grup itu :('
                if (!me.admin) {
                    return m.reply('⚠️ Saya bukan admin di grup itu. Tidak dapat mengirimkan link group.', m.chat)
                }
                let inviteCode = await conn.groupInviteCode(group)
                m.reply('https://chat.whatsapp.com/' + inviteCode)
            } catch (error) {
                m.reply(error, m.chat)
            }
        } else if (command === 'bout') {
            try {
                let groupMetadata = await conn.groupMetadata(group)
                if (!groupMetadata) throw 'groupMetadata is undefined :\\'
                if (!('participants' in groupMetadata)) throw 'Peserta tidak didefinisikan :('
                let me = groupMetadata.participants.find(user => areJidsSameUser(user.id, conn.user.id))
                if (!me) throw 'Saya tidak berada di grup itu :('
                if (!me.admin) {
                    await conn.groupLeave(group)
                    return m.reply('⚠️ Group di tutup Mikasa gak bisa kirim pesan perpisahan', m.chat)
                }
                await conn.groupLeave(group)
                
                try {
                    await conn.sendMessage(group, 'Mikasa akan out dari group\nSayonara Semuanya', { quoted: m })
                } catch (sendError) {
                    m.reply('⚠️ Group di tutup Mikasa gak bisa kirim pesan perpisahan', m.chat)
                }
            } catch (error) {
                m.reply(error, m.chat)
            }
        }
    }
}

handler.help = ['blink', 'bout']
handler.tags = ['owner']
handler.command = /^(blink|bout)$/i
handler.owner = true

export default handler