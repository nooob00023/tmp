import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import { setupMaster, fork } from 'cluster';
import chalk from 'chalk';
import os from 'os';
import fs from 'fs';
import axios from 'axios';

const __dirname = dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const package_json = JSON.parse(fs.readFileSync('./package.json'));

async function getServerInfo() {
    try {
        const ip = (await axios.get('https://api.ipify.org?format=json')).data.ip;
        const location = (await axios.get(`http://ip-api.com/json/${ip}`)).data;
        return { ip, location };
    } catch (error) {
        return { 
            ip: 'Unable to detect', 
            location: { country: 'Unknown', city: 'Unknown' } 
        };
    }
}

function getSystemInfo() {
    return {
        platform: os.platform(),
        arch: os.arch(),
        cpu: os.cpus()[0].model,
        memory: Math.round(os.totalmem() / (1024 * 1024 * 1024)),
        nodejs: process.version
    };
}

function start(file) {
    let args = [join(__dirname, file), ...process.argv.slice(2)];
    setupMaster({ exec: args[0], args: args.slice(1) });
    let p = fork();

    p.on('message', data => {
        console.log(chalk.cyan('  [RECEIVED] ') + data);
        switch(data) {
            case 'reset':
                p.kill();
                start(file);
                break;
            case 'uptime':
                p.send(process.uptime());
                break;
            default:
                break;
        }
    });

    p.on('exit', (code) => {
        console.error(chalk.red('  [ERROR] System terminated with code:'), code);
        if (code === 1) {
            start(file);
        }
    });

    return p;
}

async function displayWelcomeScreen() {
    console.clear();
    
    console.log(chalk.white.bold('\n  MIKASA MD - WhatsApp Bot Framework'));
    console.log(chalk.gray('  Version ' + package_json.version + ' (Plugins Based)\n'));

    console.log(chalk.white.bold('  System Information'));
    console.log(chalk.gray('  ──────────────────'));
    const sysInfo = getSystemInfo();
    console.log(`  Platform      : ${chalk.cyan(sysInfo.platform)}
  Architecture  : ${chalk.cyan(sysInfo.arch)}
  CPU           : ${chalk.cyan(sysInfo.cpu)}
  Memory        : ${chalk.cyan(sysInfo.memory + ' GB')}
  Node.js       : ${chalk.cyan(sysInfo.nodejs)}`);

    const serverInfo = await getServerInfo();
    console.log('\n' + chalk.white.bold('  Server Information'));
    console.log(chalk.gray('  ──────────────────'));
    console.log(`  IP Address    : ${chalk.cyan(serverInfo.ip)}
  Location      : ${chalk.cyan(serverInfo.location.city + ', ' + serverInfo.location.country)}`);

    console.log('\n' + chalk.white.bold('  Development Information'));
    console.log(chalk.gray('  ─────────────────────'));
    console.log(`  Developer     : ${chalk.cyan('Ren Collins')}
  Contributors  : ${chalk.cyan('Niaa Tania, Minanesan, Reybots')}
  Project Start : ${chalk.cyan('2023')}`);

    console.log('\n' + chalk.gray('  Starting system in 20 seconds...\n'));

    setTimeout(() => {
        console.clear();
        console.log(chalk.cyan('\n  Initializing Mikasa MD...\n'));
        start('yuzu.js');
    }, 20000);
}

displayWelcomeScreen().catch(console.error);

process.on('uncaughtException', console.error);
process.on('unhandledRejection', console.error);