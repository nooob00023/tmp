const tools = {
    api: require("./api.js"),
    general: require("./general.js"),
    list: require("./list.js"),
    msg: require("./msg.js")
};

module.exports = tools;